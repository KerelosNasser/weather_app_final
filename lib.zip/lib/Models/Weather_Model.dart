class WeatherModel {
  final String place;
  final String date;
  final String image;
  final double temp;
  final double minTemp;
  final double maxTemp;
  final String condition;

  WeatherModel({
    required this.place,
    required this.date,
    required this.image,
    required this.temp,
    required this.minTemp,
    required this.maxTemp,
    required this.condition,
  });

  factory WeatherModel.fromJson(Map<String, dynamic> json) {
    final location = json['location'] ?? {};
    final current = json['current'] ?? {};
    final forecast = (json['forecast'] ?? {})['forecastday'] ?? [];

    // Check if the forecast list is not empty and extract the first element
    final day = forecast.isNotEmpty ? forecast[0]['day'] ?? {} : {};

    return WeatherModel(
      place: location['name'] ?? 'Unknown Location',
      date: current['last_updated'] ?? 'Unknown Date',
      image: day['condition']['icon'] ?? '',
      temp: (day['avgtemp_c'] as num?)?.toDouble() ?? 0.0,
      minTemp: (day['mintemp_c'] as num?)?.toDouble() ?? 0.0,
      maxTemp: (day['maxtemp_c'] as num?)?.toDouble() ?? 0.0,
      condition: day['condition']['text'] ?? 'Unknown Condition',
    );
  }
}
