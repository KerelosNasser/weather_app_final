import 'package:flutter/material.dart';

class NoWeatherBody extends StatelessWidget {
  const NoWeatherBody({super.key});

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.only(bottom: 16),
      child: Center(
        child: Text(
          'Search for a city to get started',
          style: TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.bold,
          ),
          maxLines: 3,
          textAlign: TextAlign.center, // Added to center align the text
        ),
      ),
    );
  }
}
