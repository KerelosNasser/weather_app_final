import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:dio/dio.dart';
import '../../Models/Weather_Model.dart';
import '../../Services/Weather_Services.dart';
import 'get_weather_state.dart';

class GetWeatherCubit extends Cubit<WeatherState> {
  final WeatherServices weatherServices;

  GetWeatherCubit(this.weatherServices) : super(NoWeatherState());

  Future<void> getWeather({required String value}) async {
    emit(WeatherLoadingState());  // Corrected initial state emission
    try {
      print('Fetching weather for: $value');  // Debug statement
      WeatherModel weatherModel = await weatherServices.getCurrentWeather(cityName: value);
      print('Weather fetched successfully: ${weatherModel.temp}');  // Debug statement
      emit(WeatherLoadedState(weatherModel));
    } catch (e) {
      print('Error occurred: $e');  // Debug statement
      emit(WeatherFailureState(e.toString()));
    }
  }
}
